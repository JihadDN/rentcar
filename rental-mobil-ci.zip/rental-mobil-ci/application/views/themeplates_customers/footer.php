  <!-- Footer -->
  <footer class="py-3 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Rental Mobil  <i class="fa fa-heart-o text-danger" aria-hidden="true"></i> <?= date('Y'); ?> Amikom <a href='https://home.amikom.ac.id/' title='Amikom.ac.id/' target='_blank'>Amikom.ac.id</a>
      </p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="<?= base_url('assets/assets_shop/'); ?>vendor/jquery/jquery.min.js"></script>
  <script>
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })
  </script>
  <script src="<?= base_url('assets/assets_shop/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>