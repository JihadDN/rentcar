<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
            

            <div class="card card-primary">
              <div class="card-header"><h4>Ganti Password</h4></div>

              <div class="card-body">
              <?php if ($this->session->userdata('pesan')): ?>
                <div class="alert alert-success">
                  <?= $this->session->userdata('pesan'); ?>
                </div>
                  <?php $this->session->unset_userdata('pesan'); // Hapus pesan setelah ditampilkan ?>
                  <?php endif; ?>
                <form method="post" action="">
                  <div class="form-group">
                    <label for="passlama">Password Lama</label>
                    <input id="passlama" type="password" class="form-control" name="passlama" tabindex="1" autofocus>
                    <small class="muted text-danger"><?= form_error('passlama'); ?></small>
                  </div>

                  <div class="form-group">
                    <label for="password">Password Baru</label>
                    <input id="password" type="password" class="form-control pwstrength" data-indicator="pwindicator" name="password" tabindex="2">
                    <small class="muted text-danger"><?= form_error('password'); ?></small>
                  </div>

                  <div class="form-group">
                    <label for="password-confirm">Konformasi Password</label>
                    <input id="password-confirm" type="password" class="form-control" name="password2" tabindex="2" required>
                    <small class="muted text-danger"><?= form_error('password2'); ?></small>
                  </div>

                  <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                      Ganti Password
                    </button>
                    <a href="<?= base_url('admin/dashboard'); ?>" class="btn btn-danger btn-lg btn-block">Batal</a>
                  </div>
                </form>
              </div>
            </div>
            <div class="simple-footer">
              Copyright &copy; 2024
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>