<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
            

            <div class="card card-primary">
              <div class="card-header">
                <h2>Login</h2>
              </div>
              <div class="card-body">
                
                <br>
                

                <?php if ($this->session->userdata('pesan')): ?>
                <div class="alert alert-success">
                  <?= $this->session->userdata('pesan'); ?>
                </div>
                  <?php $this->session->unset_userdata('pesan'); // Hapus pesan setelah ditampilkan ?>
                  <?php endif; ?>
                <form method="post" action="">
                  <div class="form-group">
                    <label for="username">username</label>
                    <input id="username" type="text" class="form-control" name="username" tabindex="1" value="" autofocus>
                    <small class="muted text-danger"><?= form_error('username'); ?></small>
                  </div>

                  <div class="form-group">
                    <div class="d-block">
                      <label for="password" class="control-label">Password</label>
                    </div>
                    <input id="password" type="password" class="form-control" name="password" value="" tabindex="2">
                    <small class="muted text-danger"><?= form_error('password'); ?></small>
                  </div>

                  <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                      Login
                    </button>
                  </div>
                </form>



              </div>
            </div>
            <div class="mt-5 text-muted text-center">
              Don't have an account? <a href="<?php echo site_url('auth/daftar'); ?>">Create One</a>
            </div>
            <div class="simple-footer">
              Copyright &copy; Amikom 2024
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>